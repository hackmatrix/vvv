/* Precomp.h -- StdAfx
2013-06-16 : Igor Pavlov : Public domain */

#ifndef __7Z_PRECOMP_H
#define __7Z_PRECOMP_H

#include "../../Compiler.h"
#include "../../7zTypes.h"

#endif
